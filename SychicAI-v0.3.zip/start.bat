@echo off
chcp 65001 >nul 2>&1
title SychicAI Local Chat

:: Set environment variables for optimal performance
set SYCHIC_NO_CUDA_GRAPH=0
set SYCHIC_LM_HEAD_INT8=1
set SYCHIC_KV_INT8=1
set SYCHIC_GPU_LAYERS=26
set SYCHIC_GPU_SAMPLE=1

:: Run the chat
"%~dp0sychic-chat.exe" "%~dp0models\model.gguf"

pause
